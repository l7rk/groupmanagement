local HttpService = game:GetService("HttpService")
local ActivityConfig = require(script.Parent:WaitForChild("ActivityConfig"))

local ActivityReporter = {}

local function post(path, payload)
	local url = ActivityConfig.BOT_SERVER_URL .. path
	local body = HttpService:JSONEncode(payload)

	local success, response = pcall(function()
		return HttpService:RequestAsync({
			Url = url,
			Method = "POST",
			Headers = {
				["Content-Type"] = "application/json",
				["X-Activity-Secret"] = ActivityConfig.ACTIVITY_SECRET,
			},
			Body = body,
		})
	end)

	if not success then
		warn("[ActivityReporter] request failed: " .. tostring(response))
		return false
	end

	if not response.Success then
		warn("[ActivityReporter] non-200 response from " .. path .. ": " .. tostring(response.StatusCode) .. " " .. tostring(response.Body))
		return false
	end

	return true
end

function ActivityReporter.Heartbeat(robloxUserId, minutes, chatMessages)
	return post("/report/heartbeat", {
		guildId = ActivityConfig.GUILD_ID,
		robloxUserId = robloxUserId,
		minutes = minutes,
		chatMessages = chatMessages,
	})
end

function ActivityReporter.Afk(robloxUserId, afk)
	return post("/report/afk", {
		guildId = ActivityConfig.GUILD_ID,
		robloxUserId = robloxUserId,
		afk = afk,
	})
end

function ActivityReporter.Purchase(robloxUserId, robloxUsername, itemName, itemType, robuxAmount)
	return post("/report/purchase", {
		guildId = ActivityConfig.GUILD_ID,
		robloxUserId = robloxUserId,
		robloxUsername = robloxUsername,
		itemName = itemName,
		itemType = itemType,
		robuxAmount = robuxAmount,
	})
end

return ActivityReporter
