local Players = game:GetService("Players")

local ActivityConfig = require(script.Parent:WaitForChild("ActivityConfig"))
local ActivityReporter = require(script.Parent:WaitForChild("ActivityReporter"))

local chatCounts = {}

local function onPlayerAdded(player)
	chatCounts[player.UserId] = 0

	player.Chatted:Connect(function()
		chatCounts[player.UserId] = (chatCounts[player.UserId] or 0) + 1
	end)
end

local function onPlayerRemoving(player)
	chatCounts[player.UserId] = nil
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(onPlayerRemoving)

for _, player in ipairs(Players:GetPlayers()) do
	onPlayerAdded(player)
end

task.spawn(function()
	while true do
		task.wait(ActivityConfig.HEARTBEAT_INTERVAL_SECONDS)

		local elapsedMinutes = math.floor(ActivityConfig.HEARTBEAT_INTERVAL_SECONDS / 60)
		if elapsedMinutes < 1 then
			elapsedMinutes = 1
		end

		for _, player in ipairs(Players:GetPlayers()) do
			local messages = chatCounts[player.UserId] or 0
			chatCounts[player.UserId] = 0
			ActivityReporter.Heartbeat(player.UserId, elapsedMinutes, messages)
		end
	end
end)
