local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ActivityConfig = require(script.Parent:WaitForChild("ActivityConfig"))
local ActivityReporter = require(script.Parent:WaitForChild("ActivityReporter"))

local pingEvent = ReplicatedStorage:FindFirstChild("PlayerActivityPing")
if not pingEvent then
	pingEvent = Instance.new("RemoteEvent")
	pingEvent.Name = "PlayerActivityPing"
	pingEvent.Parent = ReplicatedStorage
end

local lastActive = {}
local afkState = {}

local function onPlayerAdded(player)
	lastActive[player.UserId] = os.time()
	afkState[player.UserId] = false
end

local function onPlayerRemoving(player)
	lastActive[player.UserId] = nil
	afkState[player.UserId] = nil
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(onPlayerRemoving)

for _, player in ipairs(Players:GetPlayers()) do
	onPlayerAdded(player)
end

pingEvent.OnServerEvent:Connect(function(player)
	lastActive[player.UserId] = os.time()
end)

task.spawn(function()
	while true do
		task.wait(ActivityConfig.AFK_CHECK_INTERVAL_SECONDS)

		for _, player in ipairs(Players:GetPlayers()) do
			local last = lastActive[player.UserId]
			if last then
				local idleFor = os.time() - last
				local isAfk = idleFor >= ActivityConfig.AFK_THRESHOLD_SECONDS

				if afkState[player.UserId] ~= isAfk then
					afkState[player.UserId] = isAfk
					ActivityReporter.Afk(player.UserId, isAfk)
				end
			end
		end
	end
end)
