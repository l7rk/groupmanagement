const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Partials, Collection, Events, EmbedBuilder } = require('discord.js');
const config = require('./config');
const roblox = require('./roblox/client');
const { startActivityServer } = require('./handlers/activityServer');
const { registerAuditLog } = require('./handlers/auditLog');
const { startScheduler } = require('./handlers/scheduler');
const { handleWordFilter } = require('./handlers/wordFilter');
const { handleAntiSpam } = require('./handlers/antiSpam');
const { getMemberTier, TIERS } = require('./utils/permissions');
const { errorEmbed } = require('./utils/embeds');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

client.commands = new Collection();

function loadCommands() {
  const baseDir = path.join(__dirname, 'commands');
  for (const tier of fs.readdirSync(baseDir)) {
    const tierDir = path.join(baseDir, tier);
    if (!fs.statSync(tierDir).isDirectory()) continue;
    for (const file of fs.readdirSync(tierDir).filter(f => f.endsWith('.js'))) {
      const command = require(path.join(tierDir, file));
      client.commands.set(command.data.name, command);
    }
  }
  console.log(`Loaded ${client.commands.size} commands`);
}

client.once(Events.ClientReady, async () => {
  console.log(`Logged in as ${client.user.tag}`);
  await roblox.init();
  startActivityServer(client);
  registerAuditLog(client);
  startScheduler(client);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isAutocomplete()) {
    const command = client.commands.get(interaction.commandName);
    if (command && command.autocomplete) {
      try {
        await command.autocomplete(interaction);
      } catch (err) {
        console.error(err);
      }
    }
    return;
  }

  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    if (command.tier !== undefined && interaction.guild) {
      const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
      const tier = member ? getMemberTier(member) : TIERS.EVERYONE;
      if (tier < command.tier) {
        return interaction.reply({
          embeds: [errorEmbed('Missing Permissions', "You don't have permission to use this command.")],
          ephemeral: true,
        });
      }
    }

    try {
      await command.execute(interaction, client);
    } catch (err) {
      console.error(err);
      const payload = { embeds: [errorEmbed('Error', 'Something went wrong running that command.')], ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
    return;
  }

  if (interaction.isButton()) {
    const handlerName = interaction.customId.split(':')[0];
    const handler = client.buttonHandlers?.get(handlerName);
    if (handler) {
      try {
        await handler(interaction, client);
      } catch (err) {
        console.error(err);
      }
    }
  }
});

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;
  const filtered = await handleWordFilter(message).catch(() => false);
  if (filtered) return;
  await handleAntiSpam(message).catch(() => {});
});

loadCommands();
client.login(config.token);
