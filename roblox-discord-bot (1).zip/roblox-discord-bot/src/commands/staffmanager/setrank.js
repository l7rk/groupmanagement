const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings, db } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const roblox = require('../../roblox/client');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('setrank')
    .setDescription('Set a specific Roblox group rank for a member')
    .addStringOption(opt => opt.setName('rank').setDescription('The target rank').setRequired(true).setAutocomplete(true))
    .addUserOption(opt => opt.setName('member').setDescription('Linked Discord member').setRequired(false))
    .addStringOption(opt => opt.setName('roblox_username').setDescription('Roblox username instead').setRequired(false)),

  async autocomplete(interaction) {
    const settings = getGuildSettings(interaction.guild.id);
    if (!settings.robloxGroupId) return interaction.respond([]);
    const focused = interaction.options.getFocused().toLowerCase();
    const roles = await roblox.getGroupRoles(settings.robloxGroupId).catch(() => []);
    const filtered = roles
      .filter(r => r.name.toLowerCase().includes(focused))
      .slice(0, 25)
      .map(r => ({ name: `${r.name} (${r.rank})`, value: r.name }));
    await interaction.respond(filtered);
  },

  async execute(interaction) {
    await interaction.deferReply();
    const settings = getGuildSettings(interaction.guild.id);
    if (!settings.robloxGroupId) {
      return interaction.editReply({ embeds: [errorEmbed('Not Configured', 'No Roblox group ID configured for this server.')] });
    }

    const rankName = interaction.options.getString('rank');

    let robloxUserId;
    const robloxUsername = interaction.options.getString('roblox_username');
    if (robloxUsername) {
      robloxUserId = await roblox.getUserIdFromUsername(robloxUsername).catch(() => null);
    } else {
      const target = interaction.options.getUser('member');
      if (!target) return interaction.editReply({ embeds: [errorEmbed('Missing Target', 'Provide a member or a Roblox username.')] });
      const link = db.prepare('SELECT * FROM roblox_links WHERE guildId = ? AND discordUserId = ?').get(interaction.guild.id, target.id);
      if (!link) return interaction.editReply({ embeds: [errorEmbed('No Roblox Link', `${target} hasn't linked a Roblox account.`)] });
      robloxUserId = link.robloxUserId;
    }

    if (!robloxUserId) {
      return interaction.editReply({ embeds: [errorEmbed('Not Found', 'Could not resolve a Roblox user for that input.')] });
    }

    try {
      await roblox.setRank(settings.robloxGroupId, robloxUserId, rankName);
      await interaction.editReply({ embeds: [successEmbed('Rank Set', `Set to **${rankName}**.`)] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Roblox Error', err.message)] });
    }
  },
};
