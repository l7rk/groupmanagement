const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getGuildSettings } = require('../../db/database');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('strike')
    .setDescription('Issue a strike to a staff member')
    .addUserOption(opt => opt.setName('member').setDescription('The staff member').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the strike').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const reason = interaction.options.getString('reason');
    const settings = getGuildSettings(interaction.guild.id);

    const now = Date.now();
    const expiresAt = now + settings.strikeExpiryDays * 24 * 60 * 60 * 1000;

    const result = db.prepare(`
      INSERT INTO strikes (guildId, userId, moderatorId, reason, createdAt, expiresAt, active)
      VALUES (?, ?, ?, ?, ?, ?, 1)
    `).run(interaction.guild.id, target.id, interaction.user.id, reason, now, expiresAt);

    const activeCount = db.prepare('SELECT COUNT(*) as c FROM strikes WHERE guildId = ? AND userId = ? AND active = 1')
      .get(interaction.guild.id, target.id).c;

    if (settings.modLogChannelId) {
      const channel = await interaction.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) {
        channel.send({ content: `⚠️ Strike #${result.lastInsertRowid} issued to ${target} by ${interaction.user}: ${reason} (${activeCount} active)` }).catch(() => {});
      }
    }

    await interaction.reply({
      embeds: [successEmbed('Strike Issued', `${target} now has **${activeCount}** active strike(s). Expires <t:${Math.floor(expiresAt / 1000)}:D>.`)],
    });
  },
};
