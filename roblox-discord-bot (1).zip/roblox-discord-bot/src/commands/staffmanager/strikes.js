const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('strikes')
    .setDescription("View a member's strikes")
    .addUserOption(opt => opt.setName('member').setDescription('The member').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const rows = db.prepare('SELECT * FROM strikes WHERE guildId = ? AND userId = ? ORDER BY createdAt DESC').all(interaction.guild.id, target.id);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('Strikes', `${target} has no strikes on record.`)] });
    }

    const lines = rows.map(r =>
      `**#${r.id}** ${r.active ? '🟡 active' : '⚪ expired'} — ${r.reason} — <t:${Math.floor(r.createdAt / 1000)}:D>`
    );

    await interaction.reply({ embeds: [infoEmbed(`⚠️ Strikes — ${target.tag}`, lines.join('\n'))] });
  },
};
