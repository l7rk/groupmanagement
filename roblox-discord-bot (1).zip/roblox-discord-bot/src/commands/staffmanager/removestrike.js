const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('removestrike')
    .setDescription('Remove a strike by ID')
    .addIntegerOption(opt => opt.setName('strike_id').setDescription('The strike ID').setRequired(true)),

  async execute(interaction) {
    const strikeId = interaction.options.getInteger('strike_id');
    const strike = db.prepare('SELECT * FROM strikes WHERE id = ? AND guildId = ?').get(strikeId, interaction.guild.id);

    if (!strike) {
      return interaction.reply({ embeds: [errorEmbed('Not Found', `No strike with ID #${strikeId} found.`)], ephemeral: true });
    }

    db.prepare('DELETE FROM strikes WHERE id = ?').run(strikeId);
    await interaction.reply({ embeds: [successEmbed('Strike Removed', `Strike #${strikeId} for <@${strike.userId}> has been removed.`)] });
  },
};
