const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getGuildSettings, getWeekStart } = require('../../db/database');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder().setName('requirementslist').setDescription('View who passed/failed weekly requirements, and who is on LOA'),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const weekStart = getWeekStart();
    const settings = getGuildSettings(guildId);

    const links = db.prepare('SELECT * FROM roblox_links WHERE guildId = ?').all(guildId);
    const overrides = db.prepare('SELECT * FROM requirements_override WHERE guildId = ? AND weekStart = ?').all(guildId, weekStart);
    const overrideMap = new Map(overrides.map(o => [o.discordUserId, o.status]));
    const activeLoas = db.prepare("SELECT userId FROM loa_requests WHERE guildId = ? AND status = 'approved'").all(guildId);
    const loaSet = new Set(activeLoas.map(l => l.userId));

    const passed = [];
    const failed = [];
    const onLoa = [];

    for (const link of links) {
      if (loaSet.has(link.discordUserId)) {
        onLoa.push(`<@${link.discordUserId}>`);
        continue;
      }
      const override = overrideMap.get(link.discordUserId);
      if (override === 'pass') {
        passed.push(`<@${link.discordUserId}>`);
        continue;
      }
      if (override === 'fail') {
        failed.push(`<@${link.discordUserId}>`);
        continue;
      }
      const activity = db.prepare('SELECT * FROM player_activity WHERE guildId = ? AND robloxUserId = ? AND weekStart = ?')
        .get(guildId, link.robloxUserId, weekStart);
      const minutes = activity?.minutesPlayed || 0;
      if (minutes >= settings.requirementMinutesPerWeek) {
        passed.push(`<@${link.discordUserId}> (${minutes} min)`);
      } else {
        failed.push(`<@${link.discordUserId}> (${minutes} min)`);
      }
    }

    const embed = infoEmbed('📋 Weekly Requirements', null)
      .addFields(
        { name: `✅ Passed (${passed.length})`, value: passed.join('\n') || 'None' },
        { name: `❌ Failed (${failed.length})`, value: failed.join('\n') || 'None' },
        { name: `📅 On LOA (${onLoa.length})`, value: onLoa.join('\n') || 'None' },
      );

    await interaction.reply({ embeds: [embed] });
  },
};
