const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('loahistory')
    .setDescription("View a member's LOA history")
    .addUserOption(opt => opt.setName('member').setDescription('The member').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const rows = db.prepare(`
      SELECT * FROM loa_requests WHERE guildId = ? AND userId = ? ORDER BY createdAt DESC LIMIT 10
    `).all(interaction.guild.id, target.id);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('LOA History', `${target} has no LOA history.`)] });
    }

    const lines = rows.map(r =>
      `**#${r.id}** — ${r.status} — <t:${Math.floor(r.startDate / 1000)}:D> to <t:${Math.floor(r.endDate / 1000)}:D>${r.endedEarly ? ' *(ended early)*' : ''}\n*${r.reason}*`
    );

    await interaction.reply({ embeds: [infoEmbed(`📅 LOA History — ${target.tag}`, lines.join('\n\n'))] });
  },
};
