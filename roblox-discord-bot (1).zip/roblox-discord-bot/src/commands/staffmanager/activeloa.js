const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder().setName('activeloa').setDescription('View everyone currently on LOA'),

  async execute(interaction) {
    const rows = db.prepare(`
      SELECT * FROM loa_requests WHERE guildId = ? AND status = 'approved' ORDER BY endDate ASC
    `).all(interaction.guild.id);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('📅 Active LOAs', 'No one is currently on LOA.')] });
    }

    const lines = rows.map(r => `<@${r.userId}> — ends <t:${Math.floor(r.endDate / 1000)}:R> — *${r.reason}*`);
    await interaction.reply({ embeds: [infoEmbed('📅 Active LOAs', lines.join('\n'))] });
  },
};
