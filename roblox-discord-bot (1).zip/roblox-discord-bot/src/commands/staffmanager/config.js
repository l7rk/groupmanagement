const { SlashCommandBuilder, ChannelType } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings, updateGuildSettings } = require('../../db/database');
const { successEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.OWNER,
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configure the bot for this server (Owner only)')
    .addSubcommand(sub => sub
      .setName('roles')
      .setDescription('Set the permission tier roles')
      .addRoleOption(o => o.setName('staff').setDescription('Staff role').setRequired(false))
      .addRoleOption(o => o.setName('staffmanager').setDescription('Staff Manager role').setRequired(false))
      .addRoleOption(o => o.setName('moderator').setDescription('Moderator role').setRequired(false))
      .addRoleOption(o => o.setName('owner').setDescription('Hidden Owner override role').setRequired(false))
      .addRoleOption(o => o.setName('loainactive').setDescription('Role applied while a staff member is on LOA').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('channels')
      .setDescription('Set the channels the bot posts to')
      .addChannelOption(o => o.setName('modlog').setDescription('Moderation log channel').addChannelTypes(ChannelType.GuildText).setRequired(false))
      .addChannelOption(o => o.setName('auditlog').setDescription('Audit log channel').addChannelTypes(ChannelType.GuildText).setRequired(false))
      .addChannelOption(o => o.setName('sessions').setDescription('Session announcement channel').addChannelTypes(ChannelType.GuildText).setRequired(false))
      .addChannelOption(o => o.setName('loaapproval').setDescription('LOA approval channel').addChannelTypes(ChannelType.GuildText).setRequired(false)))
    .addSubcommand(sub => sub
      .setName('roblox')
      .setDescription('Set the Roblox group ID')
      .addIntegerOption(o => o.setName('groupid').setDescription('Roblox group ID').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('requirements')
      .setDescription('Set the weekly playtime requirement')
      .addIntegerOption(o => o.setName('minutes').setDescription('Required minutes per week').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('afk')
      .setDescription('Set the AFK detection threshold')
      .addIntegerOption(o => o.setName('minutes').setDescription('Minutes idle before flagged AFK').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('wordfilter')
      .setDescription('Configure the word filter')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable or disable the filter').setRequired(true))
      .addStringOption(o => o.setName('words').setDescription('Comma-separated filtered words').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('antispam')
      .setDescription('Configure anti-spam')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable or disable anti-spam').setRequired(true))
      .addIntegerOption(o => o.setName('messagecount').setDescription('Messages allowed per window').setRequired(false))
      .addIntegerOption(o => o.setName('windowseconds').setDescription('Window length in seconds').setRequired(false))
      .addIntegerOption(o => o.setName('timeoutminutes').setDescription('Auto-timeout duration in minutes').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('escalation')
      .setDescription('Configure warning auto-escalation')
      .addIntegerOption(o => o.setName('kickat').setDescription('Warning count that triggers a kick').setRequired(false))
      .addIntegerOption(o => o.setName('banat').setDescription('Warning count that triggers a ban').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('strikes')
      .setDescription('Configure strike expiry')
      .addIntegerOption(o => o.setName('expirydays').setDescription('Days until a strike expires').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('sessions')
      .setDescription('Configure session cooldown')
      .addIntegerOption(o => o.setName('cooldownminutes').setDescription('Minutes between sessions per host').setRequired(true)))
    .addSubcommand(sub => sub.setName('view').setDescription('View current configuration')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'view') {
      const settings = getGuildSettings(guildId);
      const embed = infoEmbed('⚙️ Current Configuration', null).addFields(
        { name: 'Staff Role', value: settings.staffRoleId ? `<@&${settings.staffRoleId}>` : 'Not set', inline: true },
        { name: 'Staff Manager Role', value: settings.staffManagerRoleId ? `<@&${settings.staffManagerRoleId}>` : 'Not set', inline: true },
        { name: 'Moderator Role', value: settings.moderatorRoleId ? `<@&${settings.moderatorRoleId}>` : 'Not set', inline: true },
        { name: 'Owner Role', value: settings.ownerRoleId ? `<@&${settings.ownerRoleId}>` : 'Not set', inline: true },
        { name: 'LOA Inactive Role', value: settings.loaInactiveRoleId ? `<@&${settings.loaInactiveRoleId}>` : 'Not set', inline: true },
        { name: 'Mod Log Channel', value: settings.modLogChannelId ? `<#${settings.modLogChannelId}>` : 'Not set', inline: true },
        { name: 'Audit Log Channel', value: settings.auditLogChannelId ? `<#${settings.auditLogChannelId}>` : 'Not set', inline: true },
        { name: 'Session Channel', value: settings.sessionChannelId ? `<#${settings.sessionChannelId}>` : 'Not set', inline: true },
        { name: 'LOA Approval Channel', value: settings.loaApprovalChannelId ? `<#${settings.loaApprovalChannelId}>` : 'Not set', inline: true },
        { name: 'Roblox Group ID', value: settings.robloxGroupId ? `${settings.robloxGroupId}` : 'Not set', inline: true },
        { name: 'Weekly Requirement', value: `${settings.requirementMinutesPerWeek} min`, inline: true },
        { name: 'AFK Threshold', value: `${settings.afkThresholdMinutes} min`, inline: true },
        { name: 'Word Filter', value: settings.wordFilterEnabled ? 'Enabled' : 'Disabled', inline: true },
        { name: 'Anti-Spam', value: settings.antiSpamEnabled ? `Enabled (${settings.antiSpamMessageCount}/${settings.antiSpamWindowSeconds}s → ${settings.antiSpamTimeoutMinutes}m timeout)` : 'Disabled', inline: true },
        { name: 'Warn Escalation', value: `Kick @ ${settings.warnEscalationKickAt}, Ban @ ${settings.warnEscalationBanAt}`, inline: true },
        { name: 'Strike Expiry', value: `${settings.strikeExpiryDays} days`, inline: true },
        { name: 'Session Cooldown', value: `${settings.sessionCooldownMinutes} min`, inline: true },
      );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'roles') {
      const fields = {};
      const staff = interaction.options.getRole('staff');
      const staffManager = interaction.options.getRole('staffmanager');
      const moderator = interaction.options.getRole('moderator');
      const owner = interaction.options.getRole('owner');
      const loaInactive = interaction.options.getRole('loainactive');
      if (staff) fields.staffRoleId = staff.id;
      if (staffManager) fields.staffManagerRoleId = staffManager.id;
      if (moderator) fields.moderatorRoleId = moderator.id;
      if (owner) fields.ownerRoleId = owner.id;
      if (loaInactive) fields.loaInactiveRoleId = loaInactive.id;
      updateGuildSettings(guildId, fields);
    } else if (sub === 'channels') {
      const fields = {};
      const modlog = interaction.options.getChannel('modlog');
      const auditlog = interaction.options.getChannel('auditlog');
      const sessions = interaction.options.getChannel('sessions');
      const loaapproval = interaction.options.getChannel('loaapproval');
      if (modlog) fields.modLogChannelId = modlog.id;
      if (auditlog) fields.auditLogChannelId = auditlog.id;
      if (sessions) fields.sessionChannelId = sessions.id;
      if (loaapproval) fields.loaApprovalChannelId = loaapproval.id;
      updateGuildSettings(guildId, fields);
    } else if (sub === 'roblox') {
      updateGuildSettings(guildId, { robloxGroupId: interaction.options.getInteger('groupid') });
    } else if (sub === 'requirements') {
      updateGuildSettings(guildId, { requirementMinutesPerWeek: interaction.options.getInteger('minutes') });
    } else if (sub === 'afk') {
      updateGuildSettings(guildId, { afkThresholdMinutes: interaction.options.getInteger('minutes') });
    } else if (sub === 'wordfilter') {
      const fields = { wordFilterEnabled: interaction.options.getBoolean('enabled') ? 1 : 0 };
      const words = interaction.options.getString('words');
      if (words !== null) fields.wordFilterList = words;
      updateGuildSettings(guildId, fields);
    } else if (sub === 'antispam') {
      const fields = { antiSpamEnabled: interaction.options.getBoolean('enabled') ? 1 : 0 };
      const messageCount = interaction.options.getInteger('messagecount');
      const windowSeconds = interaction.options.getInteger('windowseconds');
      const timeoutMinutes = interaction.options.getInteger('timeoutminutes');
      if (messageCount !== null) fields.antiSpamMessageCount = messageCount;
      if (windowSeconds !== null) fields.antiSpamWindowSeconds = windowSeconds;
      if (timeoutMinutes !== null) fields.antiSpamTimeoutMinutes = timeoutMinutes;
      updateGuildSettings(guildId, fields);
    } else if (sub === 'escalation') {
      const fields = {};
      const kickAt = interaction.options.getInteger('kickat');
      const banAt = interaction.options.getInteger('banat');
      if (kickAt !== null) fields.warnEscalationKickAt = kickAt;
      if (banAt !== null) fields.warnEscalationBanAt = banAt;
      updateGuildSettings(guildId, fields);
    } else if (sub === 'strikes') {
      updateGuildSettings(guildId, { strikeExpiryDays: interaction.options.getInteger('expirydays') });
    } else if (sub === 'sessions') {
      updateGuildSettings(guildId, { sessionCooldownMinutes: interaction.options.getInteger('cooldownminutes') });
    }

    await interaction.reply({ embeds: [successEmbed('Configuration Updated', `Updated \`${sub}\` settings.`)], ephemeral: true });
  },
};
