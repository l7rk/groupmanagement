const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getGuildSettings } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('endloa')
    .setDescription("End a staff member's LOA early")
    .addUserOption(opt => opt.setName('member').setDescription('The staff member').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const loa = db.prepare(`
      SELECT * FROM loa_requests WHERE guildId = ? AND userId = ? AND status = 'approved' ORDER BY startDate DESC LIMIT 1
    `).get(interaction.guild.id, target.id);

    if (!loa) {
      return interaction.reply({ embeds: [errorEmbed('No Active LOA', `${target} does not have an active LOA.`)], ephemeral: true });
    }

    db.prepare("UPDATE loa_requests SET status = 'ended', endedEarly = 1 WHERE id = ?").run(loa.id);

    const settings = getGuildSettings(interaction.guild.id);
    if (settings.loaInactiveRoleId) {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      if (member) await member.roles.remove(settings.loaInactiveRoleId).catch(() => {});
    }

    await interaction.reply({ embeds: [successEmbed('LOA Ended', `LOA #${loa.id} for ${target} has been ended early by ${interaction.user}.`)] });
  },
};
