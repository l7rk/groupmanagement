const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings, db } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const roblox = require('../../roblox/client');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('promote')
    .setDescription('Promote a member on the Roblox group')
    .addUserOption(opt => opt.setName('member').setDescription('Linked Discord member').setRequired(false))
    .addStringOption(opt => opt.setName('roblox_username').setDescription('Roblox username instead').setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply();
    const settings = getGuildSettings(interaction.guild.id);
    if (!settings.robloxGroupId) {
      return interaction.editReply({ embeds: [errorEmbed('Not Configured', 'No Roblox group ID configured for this server.')] });
    }

    let robloxUserId;
    const robloxUsername = interaction.options.getString('roblox_username');
    if (robloxUsername) {
      robloxUserId = await roblox.getUserIdFromUsername(robloxUsername).catch(() => null);
    } else {
      const target = interaction.options.getUser('member');
      if (!target) return interaction.editReply({ embeds: [errorEmbed('Missing Target', 'Provide a member or a Roblox username.')] });
      const link = db.prepare('SELECT * FROM roblox_links WHERE guildId = ? AND discordUserId = ?').get(interaction.guild.id, target.id);
      if (!link) return interaction.editReply({ embeds: [errorEmbed('No Roblox Link', `${target} hasn't linked a Roblox account.`)] });
      robloxUserId = link.robloxUserId;
    }

    if (!robloxUserId) {
      return interaction.editReply({ embeds: [errorEmbed('Not Found', 'Could not resolve a Roblox user for that input.')] });
    }

    try {
      const result = await roblox.promote(settings.robloxGroupId, robloxUserId);
      await interaction.editReply({
        embeds: [successEmbed('Promoted', `Promoted from **${result.oldRole?.name || 'unknown'}** to **${result.newRole?.name || 'unknown'}**.`)],
      });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed('Roblox Error', err.message)] });
    }
  },
};
