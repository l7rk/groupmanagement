const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getWeekStart } = require('../../db/database');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF_MANAGER,
  data: new SlashCommandBuilder()
    .setName('requirementspass')
    .setDescription('Manually mark a member as having passed weekly requirements')
    .addUserOption(opt => opt.setName('member').setDescription('The member').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const weekStart = getWeekStart();

    db.prepare(`
      INSERT INTO requirements_override (guildId, discordUserId, weekStart, status, setBy)
      VALUES (?, ?, ?, 'pass', ?)
      ON CONFLICT(guildId, discordUserId, weekStart) DO UPDATE SET status = 'pass', setBy = excluded.setBy
    `).run(interaction.guild.id, target.id, weekStart, interaction.user.id);

    await interaction.reply({ embeds: [successEmbed('Requirement Marked', `${target} marked as **passed** for this week.`)] });
  },
};
