const { SlashCommandBuilder } = require('discord.js');
const { TIERS, getMemberTier } = require('../../utils/permissions');
const { infoEmbed } = require('../../utils/embeds');

const SECTIONS = [
  {
    name: '👤 Everyone',
    tier: TIERS.EVERYONE,
    commands: ['/playerstats', '/help', '/userinfo', '/serverinfo'],
  },
  {
    name: '🎫 Staff',
    tier: TIERS.STAFF,
    commands: ['/qotd', '/weeklysummary', '/loa', '/session', '/endsession', '/staffleaderboard'],
  },
  {
    name: '📋 Staff Manager',
    tier: TIERS.STAFF_MANAGER,
    commands: [
      '/endloa', '/activeloa', '/loahistory', '/strike', '/strikes', '/removestrike',
      '/requirementspass', '/requirementsfail', '/requirementslist', '/promote', '/demote', '/setrank',
    ],
  },
  {
    name: '🛡️ Moderator',
    tier: TIERS.MODERATOR,
    commands: ['/warn', '/warnings', '/clearwarns', '/kick', '/ban', '/unban', '/timeout', '/purge', '/pm'],
  },
];

module.exports = {
  tier: TIERS.EVERYONE,
  data: new SlashCommandBuilder().setName('help').setDescription('Show the command list'),

  async execute(interaction) {
    const member = interaction.member;
    const tier = member ? getMemberTier(member) : TIERS.EVERYONE;

    const embed = infoEmbed('📖 Command List', 'Commands available to your permission tier are shown below.');
    for (const section of SECTIONS) {
      if (tier >= section.tier) {
        embed.addFields({ name: section.name, value: section.commands.join(', ') });
      }
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
