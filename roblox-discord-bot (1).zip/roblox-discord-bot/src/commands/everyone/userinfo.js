const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');
const { TIERS, getMemberTier } = require('../../utils/permissions');

const TIER_NAMES = ['Everyone', 'Staff', 'Staff Manager', 'Moderator', 'Owner'];

module.exports = {
  tier: TIERS.EVERYONE,
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View info about a member')
    .addUserOption(opt => opt.setName('member').setDescription('Member to look up').setRequired(false)),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('member') || interaction.user;
    const member = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

    if (!member) {
      return interaction.reply({ embeds: [infoEmbed('User Info', `${targetUser.tag} is not a member of this server.`)], ephemeral: true });
    }

    const tier = getMemberTier(member);
    const roles = member.roles.cache
      .filter(r => r.id !== interaction.guild.id)
      .sort((a, b) => b.position - a.position)
      .map(r => r.toString())
      .slice(0, 20)
      .join(', ') || 'None';

    const embed = infoEmbed(`👤 ${member.user.tag}`, null)
      .setThumbnail(member.user.displayAvatarURL())
      .addFields(
        { name: 'ID', value: member.id, inline: true },
        { name: 'Joined Server', value: member.joinedAt ? `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>` : 'Unknown', inline: true },
        { name: 'Account Created', value: `<t:${Math.floor(member.user.createdAt.getTime() / 1000)}:R>`, inline: true },
        { name: 'Bot Permission Tier', value: TIER_NAMES[tier], inline: true },
        { name: 'Roles', value: roles },
      );

    await interaction.reply({ embeds: [embed] });
  },
};
