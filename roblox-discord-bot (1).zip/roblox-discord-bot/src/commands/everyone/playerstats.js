const { SlashCommandBuilder } = require('discord.js');
const { db, getGuildSettings, getWeekStart } = require('../../db/database');
const { TIERS } = require('../../utils/permissions');
const { infoEmbed, errorEmbed } = require('../../utils/embeds');
const roblox = require('../../roblox/client');

module.exports = {
  tier: TIERS.EVERYONE,
  data: new SlashCommandBuilder()
    .setName('playerstats')
    .setDescription("View a player's in-game stats for this week")
    .addUserOption(opt => opt.setName('member').setDescription('Member to look up (defaults to you)').setRequired(false))
    .addStringOption(opt => opt.setName('roblox_username').setDescription('Look up by Roblox username instead').setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply();
    const guildId = interaction.guild.id;
    let robloxUserId;
    let label;

    const robloxUsername = interaction.options.getString('roblox_username');
    if (robloxUsername) {
      robloxUserId = await roblox.getUserIdFromUsername(robloxUsername).catch(() => null);
      if (!robloxUserId) {
        return interaction.editReply({ embeds: [errorEmbed('Not Found', `Could not find a Roblox user named \`${robloxUsername}\`.`)] });
      }
      label = robloxUsername;
    } else {
      const targetUser = interaction.options.getUser('member') || interaction.user;
      const link = db.prepare('SELECT * FROM roblox_links WHERE guildId = ? AND discordUserId = ?').get(guildId, targetUser.id);
      if (!link) {
        return interaction.editReply({ embeds: [errorEmbed('No Roblox Link', `${targetUser} hasn't linked a Roblox account yet.`)] });
      }
      robloxUserId = link.robloxUserId;
      label = link.robloxUsername || targetUser.username;
    }

    const weekStart = getWeekStart();
    const activity = db.prepare(
      'SELECT * FROM player_activity WHERE guildId = ? AND robloxUserId = ? AND weekStart = ?'
    ).get(guildId, robloxUserId, weekStart);

    const settings = getGuildSettings(guildId);
    const minutes = activity?.minutesPlayed || 0;
    const chat = activity?.chatMessages || 0;
    const met = minutes >= settings.requirementMinutesPerWeek;

    const embed = infoEmbed(`📊 Stats for ${label}`, null)
      .addFields(
        { name: 'Playtime (this week)', value: `${minutes} min`, inline: true },
        { name: 'Chat messages (this week)', value: `${chat}`, inline: true },
        { name: 'Weekly requirement', value: `${settings.requirementMinutesPerWeek} min`, inline: true },
        { name: 'Status', value: met ? '✅ Requirement met' : '❌ Requirement not met', inline: true },
        { name: 'AFK', value: activity?.afk ? '🟡 Currently AFK' : '🟢 Active', inline: true },
      );

    await interaction.editReply({ embeds: [embed] });
  },
};
