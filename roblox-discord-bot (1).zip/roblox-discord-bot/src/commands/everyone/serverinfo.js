const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../../utils/embeds');
const { TIERS } = require('../../utils/permissions');

module.exports = {
  tier: TIERS.EVERYONE,
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('View server info'),

  async execute(interaction) {
    const guild = interaction.guild;
    const embed = infoEmbed(`🏠 ${guild.name}`, null)
      .setThumbnail(guild.iconURL())
      .addFields(
        { name: 'Members', value: `${guild.memberCount}`, inline: true },
        { name: 'Created', value: `<t:${Math.floor(guild.createdAt.getTime() / 1000)}:R>`, inline: true },
        { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Roles', value: `${guild.roles.cache.size}`, inline: true },
        { name: 'Channels', value: `${guild.channels.cache.size}`, inline: true },
        { name: 'Boost Level', value: `${guild.premiumTier}`, inline: true },
      );

    await interaction.reply({ embeds: [embed] });
  },
};
