const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const roblox = require('../../roblox/client');

module.exports = {
  tier: TIERS.EVERYONE,
  data: new SlashCommandBuilder()
    .setName('linkroblox')
    .setDescription('Link your Discord account to your Roblox account')
    .addStringOption(opt => opt.setName('username').setDescription('Your Roblox username').setRequired(true)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const username = interaction.options.getString('username');
    const robloxUserId = await roblox.getUserIdFromUsername(username).catch(() => null);

    if (!robloxUserId) {
      return interaction.editReply({ embeds: [errorEmbed('Not Found', `Could not find a Roblox user named \`${username}\`.`)] });
    }

    db.prepare(`
      INSERT INTO roblox_links (guildId, discordUserId, robloxUserId, robloxUsername)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(guildId, discordUserId) DO UPDATE SET robloxUserId = excluded.robloxUserId, robloxUsername = excluded.robloxUsername
    `).run(interaction.guild.id, interaction.user.id, robloxUserId, username);

    await interaction.editReply({ embeds: [successEmbed('Linked', `Your account is now linked to **${username}**.`)] });
  },
};
