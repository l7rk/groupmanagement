const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getWeekStart } = require('../../db/database');
const { infoEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF,
  data: new SlashCommandBuilder().setName('weeklysummary').setDescription("DM yourself last week's leaderboards"),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const weekStart = getWeekStart(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));

    const topPlaytime = db.prepare(`
      SELECT * FROM player_activity WHERE guildId = ? AND weekStart = ? ORDER BY minutesPlayed DESC LIMIT 10
    `).all(interaction.guild.id, weekStart);

    const topChat = db.prepare(`
      SELECT * FROM player_activity WHERE guildId = ? AND weekStart = ? ORDER BY chatMessages DESC LIMIT 10
    `).all(interaction.guild.id, weekStart);

    const embed = infoEmbed('📈 Last Week Summary', null)
      .addFields(
        {
          name: 'Top Playtime',
          value: topPlaytime.length
            ? topPlaytime.map((r, i) => `${i + 1}. Roblox ID ${r.robloxUserId} — ${r.minutesPlayed} min`).join('\n')
            : 'No data',
        },
        {
          name: 'Top Chat Activity',
          value: topChat.length
            ? topChat.map((r, i) => `${i + 1}. Roblox ID ${r.robloxUserId} — ${r.chatMessages} messages`).join('\n')
            : 'No data',
        },
      );

    try {
      await interaction.user.send({ embeds: [embed] });
      await interaction.editReply({ embeds: [infoEmbed('Sent', 'Check your DMs for the weekly summary.')] });
    } catch {
      await interaction.editReply({ embeds: [errorEmbed('Could Not DM', 'Please enable DMs from server members and try again.')] });
    }
  },
};
