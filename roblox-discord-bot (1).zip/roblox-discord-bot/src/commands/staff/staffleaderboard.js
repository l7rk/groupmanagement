const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getWeekStart } = require('../../db/database');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF,
  data: new SlashCommandBuilder().setName('staffleaderboard').setDescription('Top staff by in-game time this week'),

  async execute(interaction) {
    const weekStart = getWeekStart();
    const rows = db.prepare(`
      SELECT * FROM player_activity WHERE guildId = ? AND weekStart = ? ORDER BY minutesPlayed DESC LIMIT 15
    `).all(interaction.guild.id, weekStart);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('🏆 Staff Leaderboard', 'No activity recorded yet this week.')] });
    }

    const lines = await Promise.all(rows.map(async (row, i) => {
      let label = row.discordUserId ? `<@${row.discordUserId}>` : `Roblox ID ${row.robloxUserId}`;
      return `**${i + 1}.** ${label} — ${row.minutesPlayed} min, ${row.chatMessages} messages`;
    }));

    await interaction.reply({ embeds: [infoEmbed('🏆 Staff Leaderboard (This Week)', lines.join('\n'))] });
  },
};
