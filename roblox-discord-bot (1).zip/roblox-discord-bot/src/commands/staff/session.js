const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getGuildSettings } = require('../../db/database');
const { infoEmbed, errorEmbed, COLORS, baseEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF,
  data: new SlashCommandBuilder()
    .setName('session')
    .setDescription('Post a session announcement')
    .addStringOption(opt => opt.setName('title').setDescription('Session title').setRequired(true))
    .addStringOption(opt => opt.setName('details').setDescription('Extra details').setRequired(false)),

  async execute(interaction) {
    const settings = getGuildSettings(interaction.guild.id);
    const now = Date.now();

    const cooldown = db.prepare('SELECT * FROM session_cooldowns WHERE guildId = ? AND userId = ?')
      .get(interaction.guild.id, interaction.user.id);

    const cooldownMs = settings.sessionCooldownMinutes * 60 * 1000;
    if (cooldown && now - cooldown.lastSessionAt < cooldownMs) {
      const remaining = Math.ceil((cooldownMs - (now - cooldown.lastSessionAt)) / 60000);
      return interaction.reply({
        embeds: [errorEmbed('Cooldown Active', `You can host another session in ${remaining} minute(s).`)],
        ephemeral: true,
      });
    }

    const title = interaction.options.getString('title');
    const details = interaction.options.getString('details') || 'No additional details.';

    const targetChannel = settings.sessionChannelId
      ? await interaction.guild.channels.fetch(settings.sessionChannelId).catch(() => null)
      : interaction.channel;

    if (!targetChannel) {
      return interaction.reply({ embeds: [errorEmbed('Config Error', 'Session channel is not configured or not accessible.')] });
    }

    const embed = baseEmbed(COLORS.success)
      .setTitle(`🎬 Session: ${title}`)
      .setDescription(details)
      .setFooter({ text: `Hosted by ${interaction.user.tag}` });

    const message = await targetChannel.send({ content: '@here', embeds: [embed] });

    const result = db.prepare(`
      INSERT INTO sessions (guildId, channelId, messageId, hostId, title, startedAt, active)
      VALUES (?, ?, ?, ?, ?, ?, 1)
    `).run(interaction.guild.id, targetChannel.id, message.id, interaction.user.id, title, now);

    db.prepare(`
      INSERT INTO session_cooldowns (guildId, userId, lastSessionAt) VALUES (?, ?, ?)
      ON CONFLICT(guildId, userId) DO UPDATE SET lastSessionAt = excluded.lastSessionAt
    `).run(interaction.guild.id, interaction.user.id, now);

    await interaction.reply({ embeds: [infoEmbed('Session Posted', `Session #${result.lastInsertRowid} announced in ${targetChannel}.`)], ephemeral: true });

    setTimeout(async () => {
      const stillActive = db.prepare('SELECT active FROM sessions WHERE id = ?').get(result.lastInsertRowid);
      if (stillActive && stillActive.active) {
        db.prepare('UPDATE sessions SET active = 0 WHERE id = ?').run(result.lastInsertRowid);
        await message.delete().catch(() => {});
      }
    }, 3 * 60 * 60 * 1000);
  },
};
