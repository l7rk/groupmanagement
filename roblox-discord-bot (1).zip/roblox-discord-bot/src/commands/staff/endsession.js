const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF,
  data: new SlashCommandBuilder().setName('endsession').setDescription('End the active session early'),

  async execute(interaction) {
    const session = db.prepare(`
      SELECT * FROM sessions WHERE guildId = ? AND hostId = ? AND active = 1 ORDER BY startedAt DESC LIMIT 1
    `).get(interaction.guild.id, interaction.user.id);

    if (!session) {
      return interaction.reply({ embeds: [errorEmbed('No Active Session', "You don't have an active session to end.")], ephemeral: true });
    }

    db.prepare('UPDATE sessions SET active = 0 WHERE id = ?').run(session.id);

    const channel = await interaction.guild.channels.fetch(session.channelId).catch(() => null);
    if (channel && session.messageId) {
      const message = await channel.messages.fetch(session.messageId).catch(() => null);
      if (message) await message.delete().catch(() => {});
    }

    await interaction.reply({ embeds: [successEmbed('Session Ended', `Session "${session.title}" has been ended.`)], ephemeral: true });
  },
};
