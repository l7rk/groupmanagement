const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { baseEmbed, COLORS } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.STAFF,
  data: new SlashCommandBuilder()
    .setName('qotd')
    .setDescription('Post a Question of the Day')
    .addStringOption(opt => opt.setName('question').setDescription('The question to post').setRequired(true)),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const embed = baseEmbed(COLORS.primary)
      .setTitle('❓ Question of the Day')
      .setDescription(question)
      .setFooter({ text: `Asked by ${interaction.user.tag}` });

    await interaction.reply({ embeds: [embed] });
    const message = await interaction.fetchReply();
    await message.startThread({
      name: `QOTD: ${question.slice(0, 80)}`,
      autoArchiveDuration: 1440,
    }).catch(() => {});
  },
};
