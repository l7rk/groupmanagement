const { SlashCommandBuilder } = require('discord.js');
const { TIERS, hasTier } = require('../../utils/permissions');
const { db, getGuildSettings } = require('../../db/database');
const { infoEmbed, errorEmbed, successEmbed } = require('../../utils/embeds');

const DAY_MS = 24 * 60 * 60 * 1000;

module.exports = {
  tier: TIERS.STAFF,
  data: new SlashCommandBuilder()
    .setName('loa')
    .setDescription('Submit a Leave of Absence request')
    .addIntegerOption(opt => opt.setName('days').setDescription('Number of days').setRequired(true).setMinValue(1).setMaxValue(90))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the LOA').setRequired(true)),

  async execute(interaction) {
    const days = interaction.options.getInteger('days');
    const reason = interaction.options.getString('reason');
    const settings = getGuildSettings(interaction.guild.id);

    const startDate = Date.now();
    const endDate = startDate + days * DAY_MS;

    const result = db.prepare(`
      INSERT INTO loa_requests (guildId, userId, reason, startDate, endDate, status, createdAt)
      VALUES (?, ?, ?, ?, ?, 'pending', ?)
    `).run(interaction.guild.id, interaction.user.id, reason, startDate, endDate, startDate);

    const embed = infoEmbed('📅 New LOA Request', null)
      .addFields(
        { name: 'Staff Member', value: `${interaction.user}`, inline: true },
        { name: 'Duration', value: `${days} day(s)`, inline: true },
        { name: 'Ends', value: `<t:${Math.floor(endDate / 1000)}:D>`, inline: true },
        { name: 'Reason', value: reason },
      )
      .setFooter({ text: `LOA #${result.lastInsertRowid} — react ✅ to approve, ❌ to deny` });

    const targetChannel = settings.loaApprovalChannelId
      ? await interaction.guild.channels.fetch(settings.loaApprovalChannelId).catch(() => null)
      : interaction.channel;

    if (!targetChannel) {
      return interaction.reply({ embeds: [errorEmbed('Config Error', 'LOA approval channel is not configured or not accessible.')] });
    }

    const message = await targetChannel.send({ embeds: [embed] });
    await message.react('✅');
    await message.react('❌');

    db.prepare('UPDATE loa_requests SET messageId = ? WHERE id = ?').run(message.id, result.lastInsertRowid);

    await interaction.reply({ embeds: [successEmbed('LOA Submitted', 'Your Leave of Absence request has been submitted for approval.')], ephemeral: true });

    const collector = message.createReactionCollector({
      filter: (reaction, user) => !user.bot && ['✅', '❌'].includes(reaction.emoji.name),
      time: 7 * DAY_MS,
      max: 1,
    });

    collector.on('collect', async (reaction, user) => {
      const approverMember = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!approverMember || !hasTier(approverMember, TIERS.STAFF_MANAGER)) {
        await reaction.users.remove(user.id).catch(() => {});
        return;
      }

      const approved = reaction.emoji.name === '✅';
      db.prepare('UPDATE loa_requests SET status = ?, approverId = ? WHERE id = ?')
        .run(approved ? 'approved' : 'denied', user.id, result.lastInsertRowid);

      if (approved && settings.loaInactiveRoleId) {
        const staffMember = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
        if (staffMember) await staffMember.roles.add(settings.loaInactiveRoleId).catch(() => {});
      }

      const resultEmbed = infoEmbed(
        approved ? '✅ LOA Approved' : '❌ LOA Denied',
        `LOA #${result.lastInsertRowid} for ${interaction.user} was ${approved ? 'approved' : 'denied'} by ${user}.`
      );
      await message.reply({ embeds: [resultEmbed] }).catch(() => {});
    });
  },
};
