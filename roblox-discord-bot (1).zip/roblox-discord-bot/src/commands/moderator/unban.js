const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by ID')
    .addStringOption(opt => opt.setName('user_id').setDescription('The user ID to unban').setRequired(true)),

  async execute(interaction) {
    const userId = interaction.options.getString('user_id');

    try {
      await interaction.guild.members.unban(userId);
    } catch {
      return interaction.reply({ embeds: [errorEmbed('Cannot Unban', 'That user is not banned or the ID is invalid.')], ephemeral: true });
    }

    const settings = getGuildSettings(interaction.guild.id);
    if (settings.modLogChannelId) {
      const channel = await interaction.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) channel.send({ content: `♻️ User ID \`${userId}\` unbanned by ${interaction.user}` }).catch(() => {});
    }

    await interaction.reply({ embeds: [successEmbed('User Unbanned', `User ID \`${userId}\` has been unbanned.`)] });
  },
};
