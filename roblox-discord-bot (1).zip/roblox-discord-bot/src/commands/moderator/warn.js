const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db, getGuildSettings } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .addUserOption(opt => opt.setName('member').setDescription('Member to warn').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the warning').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const reason = interaction.options.getString('reason');
    const settings = getGuildSettings(interaction.guild.id);

    db.prepare(`
      INSERT INTO warnings (guildId, userId, moderatorId, reason, createdAt) VALUES (?, ?, ?, ?, ?)
    `).run(interaction.guild.id, target.id, interaction.user.id, reason, Date.now());

    const warnCount = db.prepare('SELECT COUNT(*) as c FROM warnings WHERE guildId = ? AND userId = ?')
      .get(interaction.guild.id, target.id).c;

    let escalationNote = '';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (member) {
      if (settings.warnEscalationBanAt && warnCount >= settings.warnEscalationBanAt) {
        await member.ban({ reason: `Auto-escalation: reached ${warnCount} warnings` }).catch(() => {});
        escalationNote = `\n🔨 **Auto-escalated to ban** (reached ${settings.warnEscalationBanAt} warnings)`;
      } else if (settings.warnEscalationKickAt && warnCount >= settings.warnEscalationKickAt) {
        await member.kick(`Auto-escalation: reached ${warnCount} warnings`).catch(() => {});
        escalationNote = `\n👢 **Auto-escalated to kick** (reached ${settings.warnEscalationKickAt} warnings)`;
      }
    }

    if (settings.modLogChannelId) {
      const channel = await interaction.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) {
        channel.send({ content: `⚠️ ${target} warned by ${interaction.user}: ${reason} (${warnCount} total)${escalationNote}` }).catch(() => {});
      }
    }

    await interaction.reply({ embeds: [successEmbed('Member Warned', `${target} now has **${warnCount}** warning(s).${escalationNote}`)] });
  },
};
