const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Time out a member')
    .addUserOption(opt => opt.setName('member').setDescription('Member to time out').setRequired(true))
    .addIntegerOption(opt => opt.setName('minutes').setDescription('Duration in minutes').setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the timeout').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const minutes = interaction.options.getInteger('minutes');
    const reason = interaction.options.getString('reason');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member || !member.moderatable) {
      return interaction.reply({ embeds: [errorEmbed('Cannot Timeout', 'That member cannot be timed out (missing permissions or role hierarchy).')], ephemeral: true });
    }

    await member.timeout(minutes * 60 * 1000, reason);

    const settings = getGuildSettings(interaction.guild.id);
    if (settings.modLogChannelId) {
      const channel = await interaction.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) channel.send({ content: `⏲️ ${target} timed out by ${interaction.user} for ${minutes} min: ${reason}` }).catch(() => {});
    }

    await interaction.reply({ embeds: [successEmbed('Member Timed Out', `${target.tag} has been timed out for ${minutes} minute(s).`)] });
  },
};
