const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('clearwarns')
    .setDescription("Clear a member's warnings")
    .addUserOption(opt => opt.setName('member').setDescription('The member').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const result = db.prepare('DELETE FROM warnings WHERE guildId = ? AND userId = ?').run(interaction.guild.id, target.id);
    await interaction.reply({ embeds: [successEmbed('Warnings Cleared', `Removed ${result.changes} warning(s) for ${target}.`)] });
  },
};
