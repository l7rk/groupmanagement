const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member')
    .addUserOption(opt => opt.setName('member').setDescription('Member to ban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the ban').setRequired(true))
    .addIntegerOption(opt => opt.setName('delete_days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7).setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const reason = interaction.options.getString('reason');
    const deleteDays = interaction.options.getInteger('delete_days') || 0;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (member && !member.bannable) {
      return interaction.reply({ embeds: [errorEmbed('Cannot Ban', 'That member cannot be banned (missing permissions or role hierarchy).')], ephemeral: true });
    }

    await interaction.guild.members.ban(target.id, { reason, deleteMessageSeconds: deleteDays * 86400 });

    const settings = getGuildSettings(interaction.guild.id);
    if (settings.modLogChannelId) {
      const channel = await interaction.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) channel.send({ content: `🔨 ${target.tag} banned by ${interaction.user}: ${reason}` }).catch(() => {});
    }

    await interaction.reply({ embeds: [successEmbed('Member Banned', `${target.tag} has been banned.`)] });
  },
};
