const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { db } = require('../../db/database');
const { infoEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription("View a member's warnings")
    .addUserOption(opt => opt.setName('member').setDescription('The member').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const rows = db.prepare('SELECT * FROM warnings WHERE guildId = ? AND userId = ? ORDER BY createdAt DESC').all(interaction.guild.id, target.id);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('Warnings', `${target} has no warnings on record.`)] });
    }

    const lines = rows.map(r => `**#${r.id}** — ${r.reason} — <t:${Math.floor(r.createdAt / 1000)}:D> by <@${r.moderatorId}>`);
    await interaction.reply({ embeds: [infoEmbed(`⚠️ Warnings — ${target.tag}`, lines.join('\n'))] });
  },
};
