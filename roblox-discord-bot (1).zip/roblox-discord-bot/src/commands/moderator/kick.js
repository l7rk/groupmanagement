const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings } = require('../../db/database');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member')
    .addUserOption(opt => opt.setName('member').setDescription('Member to kick').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the kick').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const reason = interaction.options.getString('reason');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member || !member.kickable) {
      return interaction.reply({ embeds: [errorEmbed('Cannot Kick', 'That member cannot be kicked (missing permissions or role hierarchy).')], ephemeral: true });
    }

    await member.kick(reason);

    const settings = getGuildSettings(interaction.guild.id);
    if (settings.modLogChannelId) {
      const channel = await interaction.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) channel.send({ content: `👢 ${target} kicked by ${interaction.user}: ${reason}` }).catch(() => {});
    }

    await interaction.reply({ embeds: [successEmbed('Member Kicked', `${target.tag} has been kicked.`)] });
  },
};
