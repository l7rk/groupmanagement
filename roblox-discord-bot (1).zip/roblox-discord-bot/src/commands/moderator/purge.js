const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { getGuildSettings } = require('../../db/database');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Bulk delete messages in this channel')
    .addIntegerOption(opt => opt.setName('amount').setDescription('Number of messages to delete (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(opt => opt.setName('member').setDescription('Only delete messages from this member').setRequired(false)),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const amount = interaction.options.getInteger('amount');
    const target = interaction.options.getUser('member');

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    let toDelete = messages;
    if (target) toDelete = messages.filter(m => m.author.id === target.id);
    toDelete = [...toDelete.values()].slice(0, amount);

    const deleted = await interaction.channel.bulkDelete(toDelete, true).catch(() => []);

    const settings = getGuildSettings(interaction.guild.id);
    if (settings.modLogChannelId) {
      const channel = await interaction.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) channel.send({ content: `🧹 ${interaction.user} purged ${deleted.size} message(s) in ${interaction.channel}${target ? ` from ${target}` : ''}` }).catch(() => {});
    }

    await interaction.editReply({ embeds: [successEmbed('Messages Purged', `Deleted ${deleted.size} message(s).`)] });
  },
};
