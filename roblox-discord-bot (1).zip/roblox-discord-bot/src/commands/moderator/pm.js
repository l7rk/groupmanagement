const { SlashCommandBuilder } = require('discord.js');
const { TIERS } = require('../../utils/permissions');
const { baseEmbed, COLORS, successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  tier: TIERS.MODERATOR,
  data: new SlashCommandBuilder()
    .setName('pm')
    .setDescription('Send a formatted DM to a member')
    .addUserOption(opt => opt.setName('member').setDescription('Member to message').setRequired(true))
    .addStringOption(opt => opt.setName('message').setDescription('Message content').setRequired(true)),

  async execute(interaction) {
    const target = interaction.options.getUser('member');
    const messageContent = interaction.options.getString('message');

    const embed = baseEmbed(COLORS.primary)
      .setTitle(`📩 Message from ${interaction.guild.name} staff`)
      .setDescription(messageContent)
      .setFooter({ text: `Sent by ${interaction.user.tag}` });

    try {
      await target.send({ embeds: [embed] });
      await interaction.reply({ embeds: [successEmbed('Message Sent', `Your message was sent to ${target}.`)], ephemeral: true });
    } catch {
      await interaction.reply({ embeds: [errorEmbed('Could Not Send', `${target} has DMs disabled or has blocked the bot.`)], ephemeral: true });
    }
  },
};
