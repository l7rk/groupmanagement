const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config');

function loadCommands() {
  const commands = [];
  const baseDir = path.join(__dirname, 'commands');
  for (const tier of fs.readdirSync(baseDir)) {
    const tierDir = path.join(baseDir, tier);
    if (!fs.statSync(tierDir).isDirectory()) continue;
    for (const file of fs.readdirSync(tierDir).filter(f => f.endsWith('.js'))) {
      const command = require(path.join(tierDir, file));
      commands.push(command.data.toJSON());
    }
  }
  return commands;
}

async function main() {
  const commands = loadCommands();
  const rest = new REST().setToken(config.token);

  const guildId = process.argv[2];

  try {
    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(config.clientId, guildId), { body: commands });
      console.log(`Deployed ${commands.length} commands to guild ${guildId}`);
    } else {
      await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
      console.log(`Deployed ${commands.length} global commands (can take up to 1 hour to propagate)`);
    }
  } catch (err) {
    console.error(err);
  }
}

main();
