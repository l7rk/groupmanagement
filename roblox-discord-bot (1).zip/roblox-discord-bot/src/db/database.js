const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '..', '..', 'data', 'bot.sqlite'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS guild_settings (
  guildId TEXT PRIMARY KEY,
  staffRoleId TEXT,
  staffManagerRoleId TEXT,
  moderatorRoleId TEXT,
  ownerRoleId TEXT,
  modLogChannelId TEXT,
  auditLogChannelId TEXT,
  sessionChannelId TEXT,
  loaApprovalChannelId TEXT,
  loaInactiveRoleId TEXT,
  robloxGroupId INTEGER,
  requirementMinutesPerWeek INTEGER DEFAULT 60,
  afkThresholdMinutes INTEGER DEFAULT 20,
  wordFilterEnabled INTEGER DEFAULT 1,
  wordFilterList TEXT DEFAULT '',
  antiSpamEnabled INTEGER DEFAULT 1,
  antiSpamMessageCount INTEGER DEFAULT 5,
  antiSpamWindowSeconds INTEGER DEFAULT 5,
  antiSpamTimeoutMinutes INTEGER DEFAULT 10,
  warnEscalationKickAt INTEGER DEFAULT 3,
  warnEscalationBanAt INTEGER DEFAULT 5,
  strikeExpiryDays INTEGER DEFAULT 30,
  sessionCooldownMinutes INTEGER DEFAULT 30
);

CREATE TABLE IF NOT EXISTS warnings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  moderatorId TEXT NOT NULL,
  reason TEXT NOT NULL,
  createdAt INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS strikes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  moderatorId TEXT NOT NULL,
  reason TEXT NOT NULL,
  createdAt INTEGER NOT NULL,
  expiresAt INTEGER NOT NULL,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS loa_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  reason TEXT NOT NULL,
  startDate INTEGER NOT NULL,
  endDate INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',
  approverId TEXT,
  messageId TEXT,
  endedEarly INTEGER DEFAULT 0,
  createdAt INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  channelId TEXT NOT NULL,
  messageId TEXT,
  hostId TEXT NOT NULL,
  title TEXT NOT NULL,
  startedAt INTEGER NOT NULL,
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS session_cooldowns (
  guildId TEXT NOT NULL,
  userId TEXT NOT NULL,
  lastSessionAt INTEGER NOT NULL,
  PRIMARY KEY (guildId, userId)
);

CREATE TABLE IF NOT EXISTS player_activity (
  guildId TEXT NOT NULL,
  robloxUserId INTEGER NOT NULL,
  discordUserId TEXT,
  weekStart INTEGER NOT NULL,
  minutesPlayed INTEGER DEFAULT 0,
  chatMessages INTEGER DEFAULT 0,
  lastReportAt INTEGER,
  afk INTEGER DEFAULT 0,
  PRIMARY KEY (guildId, robloxUserId, weekStart)
);

CREATE TABLE IF NOT EXISTS purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT NOT NULL,
  robloxUserId INTEGER NOT NULL,
  robloxUsername TEXT,
  itemName TEXT NOT NULL,
  itemType TEXT NOT NULL,
  robuxAmount INTEGER NOT NULL,
  createdAt INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS requirements_override (
  guildId TEXT NOT NULL,
  discordUserId TEXT NOT NULL,
  weekStart INTEGER NOT NULL,
  status TEXT NOT NULL,
  setBy TEXT NOT NULL,
  PRIMARY KEY (guildId, discordUserId, weekStart)
);

CREATE TABLE IF NOT EXISTS roblox_links (
  guildId TEXT NOT NULL,
  discordUserId TEXT NOT NULL,
  robloxUserId INTEGER NOT NULL,
  robloxUsername TEXT,
  PRIMARY KEY (guildId, discordUserId)
);
`);

function getGuildSettings(guildId) {
  let row = db.prepare('SELECT * FROM guild_settings WHERE guildId = ?').get(guildId);
  if (!row) {
    db.prepare('INSERT INTO guild_settings (guildId) VALUES (?)').run(guildId);
    row = db.prepare('SELECT * FROM guild_settings WHERE guildId = ?').get(guildId);
  }
  return row;
}

function updateGuildSettings(guildId, fields) {
  getGuildSettings(guildId);
  const keys = Object.keys(fields);
  if (keys.length === 0) return;
  const setClause = keys.map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE guild_settings SET ${setClause} WHERE guildId = @guildId`).run({ ...fields, guildId });
}

function getWeekStart(date = new Date()) {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = d.getUTCDay();
  const diff = (day === 0 ? -6 : 1) - day;
  d.setUTCDate(d.getUTCDate() + diff);
  d.setUTCHours(0, 0, 0, 0);
  return d.getTime();
}

module.exports = { db, getGuildSettings, updateGuildSettings, getWeekStart };
