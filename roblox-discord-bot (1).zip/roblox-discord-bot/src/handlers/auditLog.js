const { Events } = require('discord.js');
const { getGuildSettings } = require('../db/database');

async function getAuditChannel(guild) {
  const settings = getGuildSettings(guild.id);
  if (!settings.auditLogChannelId) return null;
  return guild.channels.fetch(settings.auditLogChannelId).catch(() => null);
}

function registerAuditLog(client) {
  client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;
    const channel = await getAuditChannel(newMessage.guild);
    if (!channel) return;
    channel.send({
      content: `✏️ **Message edited** by ${newMessage.author} in ${newMessage.channel}\n**Before:** ${oldMessage.content || '*unknown*'}\n**After:** ${newMessage.content}`,
    }).catch(() => {});
  });

  client.on(Events.MessageDelete, async (message) => {
    if (!message.guild || message.author?.bot) return;
    const channel = await getAuditChannel(message.guild);
    if (!channel) return;
    channel.send({
      content: `🗑️ **Message deleted** by ${message.author || 'unknown'} in ${message.channel}\n**Content:** ${message.content || '*unknown*'}`,
    }).catch(() => {});
  });

  client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
    const channel = await getAuditChannel(newMember.guild);
    if (!channel) return;

    const addedRoles = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
    const removedRoles = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id));

    if (addedRoles.size > 0) {
      channel.send({ content: `➕ **Role(s) added** to ${newMember}: ${addedRoles.map(r => r.name).join(', ')}` }).catch(() => {});
    }
    if (removedRoles.size > 0) {
      channel.send({ content: `➖ **Role(s) removed** from ${newMember}: ${removedRoles.map(r => r.name).join(', ')}` }).catch(() => {});
    }
    if (oldMember.nickname !== newMember.nickname) {
      channel.send({ content: `📝 **Nickname changed** for ${newMember}: \`${oldMember.nickname || 'none'}\` → \`${newMember.nickname || 'none'}\`` }).catch(() => {});
    }
  });

  client.on(Events.ChannelCreate, async (channelObj) => {
    if (!channelObj.guild) return;
    const channel = await getAuditChannel(channelObj.guild);
    if (!channel) return;
    channel.send({ content: `📁 **Channel created:** ${channelObj}` }).catch(() => {});
  });

  client.on(Events.ChannelDelete, async (channelObj) => {
    if (!channelObj.guild) return;
    const channel = await getAuditChannel(channelObj.guild);
    if (!channel) return;
    channel.send({ content: `📁 **Channel deleted:** ${channelObj.name}` }).catch(() => {});
  });
}

module.exports = { registerAuditLog };
