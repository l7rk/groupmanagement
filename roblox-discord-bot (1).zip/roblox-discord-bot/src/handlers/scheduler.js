const { db, getGuildSettings } = require('../db/database');

async function expireStrikes(client) {
  const now = Date.now();
  const expired = db.prepare('SELECT * FROM strikes WHERE active = 1 AND expiresAt <= ?').all(now);
  for (const strike of expired) {
    db.prepare('UPDATE strikes SET active = 0 WHERE id = ?').run(strike.id);
    const settings = getGuildSettings(strike.guildId);
    if (settings.modLogChannelId) {
      const guild = await client.guilds.fetch(strike.guildId).catch(() => null);
      if (!guild) continue;
      const channel = await guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) {
        channel.send({ content: `⏳ Strike #${strike.id} for <@${strike.userId}> has expired.` }).catch(() => {});
      }
    }
  }
}

async function expireLoas(client) {
  const now = Date.now();
  const expired = db.prepare("SELECT * FROM loa_requests WHERE status = 'approved' AND endDate <= ?").all(now);
  for (const loa of expired) {
    db.prepare("UPDATE loa_requests SET status = 'ended' WHERE id = ?").run(loa.id);
    const settings = getGuildSettings(loa.guildId);
    const guild = await client.guilds.fetch(loa.guildId).catch(() => null);
    if (!guild) continue;
    if (settings.loaInactiveRoleId) {
      const member = await guild.members.fetch(loa.userId).catch(() => null);
      if (member) {
        await member.roles.remove(settings.loaInactiveRoleId).catch(() => {});
      }
    }
    if (settings.modLogChannelId) {
      const channel = await guild.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) {
        channel.send({ content: `📅 LOA for <@${loa.userId}> has ended.` }).catch(() => {});
      }
    }
  }
}

function startScheduler(client) {
  setInterval(() => {
    expireStrikes(client).catch(err => console.error('[scheduler] strike expiry error', err));
    expireLoas(client).catch(err => console.error('[scheduler] loa expiry error', err));
  }, 5 * 60 * 1000);
}

module.exports = { startScheduler };
