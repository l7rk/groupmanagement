const express = require('express');
const config = require('../config');
const { db, getGuildSettings, getWeekStart } = require('../db/database');

function requireSecret(req, res, next) {
  const header = req.headers['x-activity-secret'];
  if (!header || header !== config.activityServerSecret) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

function upsertActivity(guildId, robloxUserId, deltaMinutes, deltaChatMessages) {
  const weekStart = getWeekStart();
  const existing = db.prepare(
    'SELECT * FROM player_activity WHERE guildId = ? AND robloxUserId = ? AND weekStart = ?'
  ).get(guildId, robloxUserId, weekStart);

  if (existing) {
    db.prepare(`
      UPDATE player_activity
      SET minutesPlayed = minutesPlayed + ?, chatMessages = chatMessages + ?, lastReportAt = ?, afk = 0
      WHERE guildId = ? AND robloxUserId = ? AND weekStart = ?
    `).run(deltaMinutes, deltaChatMessages, Date.now(), guildId, robloxUserId, weekStart);
  } else {
    db.prepare(`
      INSERT INTO player_activity (guildId, robloxUserId, weekStart, minutesPlayed, chatMessages, lastReportAt, afk)
      VALUES (?, ?, ?, ?, ?, ?, 0)
    `).run(guildId, robloxUserId, weekStart, deltaMinutes, deltaChatMessages, Date.now());
  }
}

function startActivityServer(client) {
  const app = express();
  app.use(express.json());

  app.post('/report/heartbeat', requireSecret, (req, res) => {
    const { guildId, robloxUserId, minutes = 1, chatMessages = 0 } = req.body || {};
    if (!guildId || !robloxUserId) return res.status(400).json({ error: 'missing guildId or robloxUserId' });
    upsertActivity(guildId, Number(robloxUserId), Number(minutes), Number(chatMessages));
    res.json({ ok: true });
  });

  app.post('/report/afk', requireSecret, (req, res) => {
    const { guildId, robloxUserId, afk } = req.body || {};
    if (!guildId || !robloxUserId) return res.status(400).json({ error: 'missing guildId or robloxUserId' });
    const weekStart = getWeekStart();
    db.prepare(`
      INSERT INTO player_activity (guildId, robloxUserId, weekStart, afk, lastReportAt)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(guildId, robloxUserId, weekStart) DO UPDATE SET afk = excluded.afk, lastReportAt = excluded.lastReportAt
    `).run(guildId, Number(robloxUserId), weekStart, afk ? 1 : 0, Date.now());
    res.json({ ok: true });
  });

  app.post('/report/purchase', requireSecret, async (req, res) => {
    const { guildId, robloxUserId, robloxUsername, itemName, itemType, robuxAmount } = req.body || {};
    if (!guildId || !robloxUserId || !itemName || !robuxAmount) {
      return res.status(400).json({ error: 'missing required fields' });
    }
    db.prepare(`
      INSERT INTO purchases (guildId, robloxUserId, robloxUsername, itemName, itemType, robuxAmount, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(guildId, Number(robloxUserId), robloxUsername || null, itemName, itemType || 'unknown', Number(robuxAmount), Date.now());

    const settings = getGuildSettings(guildId);
    if (settings.modLogChannelId) {
      const channel = await client.channels.fetch(settings.modLogChannelId).catch(() => null);
      if (channel) {
        channel.send({
          content: `🛒 **${robloxUsername || robloxUserId}** purchased **${itemName}** (${itemType || 'item'}) for **${robuxAmount} R$**`,
        }).catch(() => {});
      }
    }
    res.json({ ok: true });
  });

  app.listen(config.activityServerPort, () => {
    console.log(`[activity-server] Listening on port ${config.activityServerPort}`);
  });
}

module.exports = { startActivityServer };
