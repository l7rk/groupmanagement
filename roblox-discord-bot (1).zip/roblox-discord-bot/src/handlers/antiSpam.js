const { getGuildSettings } = require('../db/database');

const recentMessages = new Map();

function keyFor(guildId, userId) {
  return `${guildId}:${userId}`;
}

async function handleAntiSpam(message) {
  if (message.author.bot || !message.guild) return false;
  const settings = getGuildSettings(message.guild.id);
  if (!settings.antiSpamEnabled) return false;

  const key = keyFor(message.guild.id, message.author.id);
  const now = Date.now();
  const windowMs = settings.antiSpamWindowSeconds * 1000;

  const entry = recentMessages.get(key) || [];
  const filtered = entry.filter(ts => now - ts < windowMs);
  filtered.push(now);
  recentMessages.set(key, filtered);

  if (filtered.length > settings.antiSpamMessageCount) {
    recentMessages.set(key, []);
    const member = await message.guild.members.fetch(message.author.id).catch(() => null);
    if (member && member.moderatable) {
      await member.timeout(settings.antiSpamTimeoutMinutes * 60 * 1000, 'Anti-spam auto-timeout').catch(() => {});
      const notice = await message.channel.send({
        content: `${message.author} has been timed out for ${settings.antiSpamTimeoutMinutes} minutes for spamming.`,
      });
      setTimeout(() => notice.delete().catch(() => {}), 8000);

      if (settings.modLogChannelId) {
        const channel = await message.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
        if (channel) {
          channel.send({ content: `🚫 Auto-timeout: ${message.author} for spam (${filtered.length} messages in ${settings.antiSpamWindowSeconds}s)` }).catch(() => {});
        }
      }
    }
    return true;
  }
  return false;
}

module.exports = { handleAntiSpam };
