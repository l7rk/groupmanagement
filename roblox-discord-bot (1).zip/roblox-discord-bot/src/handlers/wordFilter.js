const { getGuildSettings } = require('../db/database');

async function handleWordFilter(message) {
  if (message.author.bot || !message.guild) return false;
  const settings = getGuildSettings(message.guild.id);
  if (!settings.wordFilterEnabled) return false;
  const words = (settings.wordFilterList || '').split(',').map(w => w.trim().toLowerCase()).filter(Boolean);
  if (words.length === 0) return false;

  const content = message.content.toLowerCase();
  const hit = words.find(w => content.includes(w));
  if (!hit) return false;

  await message.delete().catch(() => {});
  const warning = await message.channel.send({
    content: `${message.author}, your message was removed for containing a filtered word.`,
  });
  setTimeout(() => warning.delete().catch(() => {}), 6000);

  if (settings.modLogChannelId) {
    const channel = await message.guild.channels.fetch(settings.modLogChannelId).catch(() => null);
    if (channel) {
      channel.send({
        content: `🧹 Word filter triggered by ${message.author} in ${message.channel}: \`${hit}\``,
      }).catch(() => {});
    }
  }
  return true;
}

module.exports = { handleWordFilter };
