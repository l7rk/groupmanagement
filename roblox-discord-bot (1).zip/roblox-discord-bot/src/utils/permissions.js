const { getGuildSettings } = require('../db/database');
const config = require('../config');

const TIERS = {
  EVERYONE: 0,
  STAFF: 1,
  STAFF_MANAGER: 2,
  MODERATOR: 3,
  OWNER: 4,
};

function getMemberTier(member) {
  if (config.ownerUserIds.includes(member.id)) return TIERS.OWNER;

  const settings = getGuildSettings(member.guild.id);
  const roles = member.roles.cache;

  const ownerRoleId = settings.ownerRoleId || config.ownerRoleId;
  if (ownerRoleId && roles.has(ownerRoleId)) return TIERS.OWNER;
  if (member.permissions.has('Administrator')) return TIERS.OWNER;

  if (settings.moderatorRoleId && roles.has(settings.moderatorRoleId)) return TIERS.MODERATOR;
  if (settings.staffManagerRoleId && roles.has(settings.staffManagerRoleId)) return TIERS.STAFF_MANAGER;
  if (settings.staffRoleId && roles.has(settings.staffRoleId)) return TIERS.STAFF;

  return TIERS.EVERYONE;
}

function hasTier(member, requiredTier) {
  return getMemberTier(member) >= requiredTier;
}

module.exports = { TIERS, getMemberTier, hasTier };
