require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  robloxCookie: process.env.ROBLOX_COOKIE || null,
  robloxGroupId: process.env.ROBLOX_GROUP_ID ? Number(process.env.ROBLOX_GROUP_ID) : null,
  activityServerPort: process.env.ACTIVITY_SERVER_PORT || 3000,
  activityServerSecret: process.env.ACTIVITY_SERVER_SECRET || 'change-me',
  ownerRoleId: process.env.OWNER_ROLE_ID || null,
  ownerUserIds: (process.env.OWNER_USER_IDS || '').split(',').map(s => s.trim()).filter(Boolean),
};
