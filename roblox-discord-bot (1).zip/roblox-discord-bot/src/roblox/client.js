const noblox = require('noblox.js');
const config = require('../config');

let loggedIn = false;
let currentUser = null;

async function init() {
  if (!config.robloxCookie) {
    console.warn('[roblox] No ROBLOX_COOKIE set — rank management will be unavailable, read-only calls will still work.');
    return;
  }
  try {
    currentUser = await noblox.setCookie(config.robloxCookie);
    loggedIn = true;
    console.log(`[roblox] Logged in as ${currentUser.name} (${currentUser.id})`);
  } catch (err) {
    console.error('[roblox] Failed to log in with provided cookie:', err.message);
  }
}

async function getGroupRoles(groupId) {
  const roles = await noblox.getRoles(groupId);
  return roles;
}

async function getUserIdFromUsername(username) {
  const id = await noblox.getIdFromUsername(username);
  return id;
}

async function getUsernameFromUserId(userId) {
  const info = await noblox.getUsernameFromId(userId);
  return info;
}

async function getRankInGroup(groupId, userId) {
  const rank = await noblox.getRankInGroup(groupId, userId);
  return rank;
}

async function setRank(groupId, userId, rankNumberOrName) {
  if (!loggedIn) throw new Error('Bot is not authenticated with Roblox. Set ROBLOX_COOKIE in your .env.');
  return noblox.setRank(groupId, userId, rankNumberOrName);
}

async function promote(groupId, userId) {
  if (!loggedIn) throw new Error('Bot is not authenticated with Roblox. Set ROBLOX_COOKIE in your .env.');
  return noblox.promote(groupId, userId);
}

async function demote(groupId, userId) {
  if (!loggedIn) throw new Error('Bot is not authenticated with Roblox. Set ROBLOX_COOKIE in your .env.');
  return noblox.demote(groupId, userId);
}

function isAuthenticated() {
  return loggedIn;
}

module.exports = {
  init,
  getGroupRoles,
  getUserIdFromUsername,
  getUsernameFromUserId,
  getRankInGroup,
  setRank,
  promote,
  demote,
  isAuthenticated,
};
